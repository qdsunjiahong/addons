# -*- coding: utf-8 -*-
###########################################################################################
#
#    module name for OpenERP
#    Copyright (C) 2015 qdodoo Technology CO.,LTD. (<http://www.qdodoo.com/>).
#
###########################################################################################

import qdodoo_stock_demand
import qdodoo_procurement_order_inhert
import qdodoo_stock_move_inherit
import wizard
# import qdodoo_stock_demand_inherit

#引入模型

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: